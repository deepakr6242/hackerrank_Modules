
def expenditure(cart):

	total_amount=[]
	try:

		for i in range(len(cart)):
			print " {} {} {}".format(cart[i][0],cart[i][1],cart[i][3]*cart[i][2])
			total_amount.append(cart[i][3]*cart[i][2])
		total_amount=sum(total_amount)
		return total_amount
	except Exception as e:
	 return e


if __name__ == "__main__":
	cart=[['IT445','FISH',12,2.79],['IT123','PISTLE',5,11.3],['BK001','Yannie',1,123.15]]
	print expenditure(cart)



