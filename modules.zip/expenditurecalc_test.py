from unittest import TestCase
import unittest
from expenditurecalc import expenditure


class Test_expenditure(unittest.TestCase):

   def test_expend(self):
      print("Running...", self._testMethodName)
      cart=[['IT123','Jelly',12,2.79],['IT345','GOLD',5,11.3]]
      self.assertEqual(expenditure(cart),89.98)


if __name__ == '__main__':
    unittest.main()