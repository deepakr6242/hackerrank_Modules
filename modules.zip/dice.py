import random


def dice():


##Role a dice  to certain number  of times and get random number from 1-6
 try:
	 count = 0
	 while count < 30:
	   print """rolling the dice  ---
	   	----
	   	| x |
	   	---- 
	   	| x |
	   	-----
	   	| x |
	   	---- 
	   	 ----
	   	| x |
	   	---- 
	   	| x |
	   	-----
	   	| x |
	   	---- """
	   print "The dice number is "+str(random.randint(1,6))

	   
	   user=raw_input("Do you want to continue? say Yes  to continue the game and No to stop"+'\n')
	   if  user == 'yes' or user ==  'y':
	   	print """rolling the dice  ---
	   	----
	   	| x |
	   	---- 
	   	| x |
	   	-----
	   	| x |
	   	---- 
	   	 ----
	   	| x |
	   	---- 
	   	| x |
	   	-----
	   	| x |
	   	---- """
	   	count=count+1
	   else:
	   	print"You are out of Game"
	   	break

 except Exception as e:
     print "cant roll the dice due to {}".format(e)

if __name__=='__main__':
   dice()





